import styled from "styled-components";
import { Row } from "react-bootstrap";

export const MyRow = styled(Row)`
  justify-content: center;
  text-align: center;
`;
