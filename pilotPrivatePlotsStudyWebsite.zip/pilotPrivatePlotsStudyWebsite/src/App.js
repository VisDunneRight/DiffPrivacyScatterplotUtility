import './App.css';
import Section from './Section'

function App() {
  return <Section/>;
}

export default App;
