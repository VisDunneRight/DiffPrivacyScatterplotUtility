// Implemented by Jia XU
// 2011-05
// Please contact use:
// xujia@ise.neu.edu.cn 

#include "Utilities.h"
#include "DP.h"


//Mean-StructureFirst
void structureFirst(double* oricounts, int n, double* noicounts, int n1, double epsilon,long seed);
