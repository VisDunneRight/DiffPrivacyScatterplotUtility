echo 'Setup dawa'
cd ./dawa
./setup.sh
cd ..